// Adopted from: https://www.geeksforgeeks.org/dsa/ford-fulkerson-algorithm-for-maximum-flow-problem/
package nl.uu.maze.benchmarks;

public class FordFulkerson {
    static class Node<T> {
        T value;
        Node<T> next;

        Node(T v) {
            value = v;
        }
    }

    static class Queue<T> {
        private Node<T> head;
        private Node<T> tail;

        public boolean add(T value) {
            Node<T> node = new Node<>(value);
            if (head == null) {
                head = node;
            } else {
                tail.next = node;
            }
            tail = node;
            return true;
        }

        public T remove() {
            T value = head.value;
            head = head.next;
            return value;
        }

        public boolean isEmpty() {
            return head == null && tail == null;
        }
    }

    // Finds an augmenting path from source to sink in the residual graph
    public static boolean bfs(int[][] rGraph, int src, int sink, int[] parent) {
        int V = rGraph.length;
        boolean[] vis = new boolean[V];
        Queue<Integer> q = new Queue<Integer>();
        q.add(src);
        vis[src] = true;
        parent[src] = -1;

        while (!q.isEmpty()) {
            int u = q.remove();
            // Explore all adjacent vertices
            for (int v = 1; v < V; v++) {
                // Visit only unvisited vertices having positive residual capacity
                if (!vis[v] && rGraph[u][v] > 0) {
                    vis[v] = true;
                    parent[v] = u;
                    // Sink reached, augmenting path found
                    if (v == sink)
                        return true;
                    q.add(v);
                }
            }
        }
        return false;
    }

    // Returns the maximum flow from source (1) to sink (V)
    public static int findMaxFlow(int V, int[][] edges) {
        if (V > 1000)
            throw new IllegalArgumentException("Weights must be non-negative");
        // Capacity graph
        int[][] graph = new int[V + 1][V + 1];
        for (int i = 0; i < edges.length; i++) {
            int[] edge = edges[i];
            int u = edge[0];
            int v = edge[1];
            int cap = edge[2];
            graph[u][v] = cap;
        }

        // Residual graph initially equals the capacity graph
        int[][] rGraph = new int[V + 1][V + 1];
        for (int i = 0; i <= V; i++) {
            for (int j = 0; j <= graph[i].length; j++) {
                rGraph[i][j] = graph[i][j];
            }
        }

        int src = 1;
        int sink = V;

        int[] parent = new int[V + 1];
        int maxFlow = 0;

        // Keep finding augmenting paths
        while (bfs(rGraph, src, sink, parent)) {
            int pathFlow = 2147483647;
            // Find bottleneck capacity of the current path
            for (int v = sink; v != src; v = parent[v]) {
                int u = parent[v];
                pathFlow = pathFlow < rGraph[u][v] ? pathFlow : rGraph[u][v];
            }

            // Update residual capacities of forward and reverse edges
            for (int v = sink; v != src; v = parent[v]) {
                int u = parent[v];
                rGraph[u][v] -= pathFlow;
                rGraph[v][u] += pathFlow;
            }
            // Add path flow to the total maximum flow
            maxFlow += pathFlow;
        }
        return maxFlow;
    }
}
