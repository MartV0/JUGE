package nl.uu.maze.benchmarks;

public class LongestCommonSubsequence {
    public static char[] longestCommonSubsequence(char[] a, char[] b) {
        if (a.length > 128 || b.length > 128)
            throw new IllegalArgumentException("Input too long");
 
        int n = a.length, m = b.length;
        int[][] t = new int[n + 1][m + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a[i - 1] == b[j - 1]) {
                    t[i][j] = t[i - 1][j - 1] + 1;
                } else {
                    t[i][j] = t[i - 1][j] > t[i][j - 1] ? t[i - 1][j] : t[i][j - 1];
                }
            }
        }
 
        // Backtrack through the table to rebuild the sequence
        int len = t[n][m];
        char[] out = new char[len];
        int i = n, j = m, k = len;
        while (i > 0 && j > 0) {
            if (a[i - 1] == b[j - 1]) {
                out[--k] = a[i - 1];
                i--;
                j--;
            } else if (t[i - 1][j] >= t[i][j - 1]) {
                i--;
            } else {
                j--;
            }
        }
        return out;
    }
}
