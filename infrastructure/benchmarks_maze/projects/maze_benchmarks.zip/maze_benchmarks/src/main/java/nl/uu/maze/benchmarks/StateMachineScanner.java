package nl.uu.maze.benchmarks;

/**
 * Benchmark class with two loop-carried state machines: a CSV field counter
 * (with quoting) and a number-format validator.
 * <p>
 * The branch taken in each iteration depends on the state produced by the
 * previous iterations, not just on the current character. Consequently:
 * <ul>
 * <li>Edge-pair coverage across the loop back edge requires specific
 * <i>sequences</i> of characters (e.g., a quote inside a quoted field followed
 * by another quote).</li>
 * <li>Prime paths that go around the loop two or three times (state A, then B,
 * then C) need inputs of a specific length and shape.</li>
 * <li>Many (state, character class) combinations are infeasible at a given
 * iteration, which creates infeasible prime paths.</li>
 * <li>Basis path coverage stays small, because the number of independent paths
 * is only linear in the number of states, so it hides the sequence structure
 * that the other metrics expose.</li>
 * </ul>
 */
public class StateMachineScanner {
    /**
     * Counts the fields in a CSV line. Fields may be quoted with '"', and a
     * doubled quote inside a quoted field is an escaped quote.
     * Returns -1 if the line is malformed (stray quote in an unquoted field,
     * text after a closing quote, or an unterminated quoted field).
     */
    public static int countFields(char[] line) {
        final int START = 0;
        final int UNQUOTED = 1;
        final int QUOTED = 2;
        final int QUOTE_IN_QUOTED = 3;

        int state = START;
        int fields = 1;
        for (int i = 0; i < line.length; i++) {
            char c = line[i];
            switch (state) {
                case START:
                    if (c == '"') {
                        state = QUOTED;
                    } else if (c == ',') {
                        fields++; // empty field
                    } else {
                        state = UNQUOTED;
                    }
                    break;
                case UNQUOTED:
                    if (c == ',') {
                        fields++;
                        state = START;
                    } else if (c == '"') {
                        return -1;
                    }
                    break;
                case QUOTED:
                    if (c == '"') {
                        state = QUOTE_IN_QUOTED;
                    }
                    break;
                case QUOTE_IN_QUOTED:
                    if (c == '"') {
                        state = QUOTED; // escaped quote
                    } else if (c == ',') {
                        fields++;
                        state = START;
                    } else {
                        return -1;
                    }
                    break;
            }
        }
        if (state == QUOTED) {
            return -1; // unterminated quote
        }
        return fields;
    }
}
